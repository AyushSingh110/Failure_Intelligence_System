from fastapi import APIRouter
from app.schemas import InferenceRequest

router = APIRouter()   
from fastapi import APIRouter
from app.schemas import InferenceRequest

router = APIRouter()   

@router.post("/track")
def track_inference(request: InferenceRequest):
    return {
        "status": "received",
        "request_id": request.request_id
    }
    