from fastapi import FastAPI
from app.routes import router   # 👈 IMPORTANT

app = FastAPI()

app.include_router(router)      # 👈 THIS LINE IS MISSING

@app.get("/")
def root():
    return {"message": "Failure Intelligence System is running"}