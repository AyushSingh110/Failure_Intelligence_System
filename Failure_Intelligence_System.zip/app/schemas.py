from pydantic import BaseModel
from typing import Optional
from datetime import datetime


class InferenceRequest(BaseModel):
    request_id: str
    timestamp: datetime

    model_name: str
    model_version: str
    temperature: float
    latency_ms: float

    input_text: str
    output_text: str

    ground_truth: Optional[str] = None
    is_correct: Optional[bool] = None

    confidence: float
    entropy: float
    logit_margin: float
    agreement_score: float
    fsd_score: float
    consistency_entropy: float
    embedding_distance: float

    embedding_id: str